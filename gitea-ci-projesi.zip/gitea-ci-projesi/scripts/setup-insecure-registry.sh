#!/usr/bin/env bash
set -euo pipefail
: "${HOST_IP:?HOST_IP tanimlayin: HOST_IP=192.168.x.x sudo -E bash ...}"
python3 - "$HOST_IP" <<'PY'
import json, pathlib, sys
p=pathlib.Path('/etc/docker/daemon.json')
data=json.loads(p.read_text()) if p.exists() else {}
registry=f'{sys.argv[1]}:3001'
entries=data.setdefault('insecure-registries', [])
if registry not in entries: entries.append(registry)
p.write_text(json.dumps(data,indent=2)+'\n')
print('Docker insecure registry eklendi:',registry)
PY
systemctl restart docker
