# Gitea + Python + Docker + Actions + Container Registry

## Amaç
`main` dalına her push sonrasında Runner, Python uygulamasından Docker image oluşturur ve Gitea Container Registry'ye `latest` ve commit SHA etiketleriyle push eder.

## Ön koşullar
Ubuntu 24.04, Docker Engine + Compose plugin, Git; host LAN IP'si; Gitea web erişimi; test için güvenilir izole ağ. Bu örnek **HTTP registry** kullanır ve yalnızca laboratuvar içindir. İş yeri ağı için BT onayı alın; üretimde DNS+TLS, ayrı izole runner ve dar yetkili token tercih edin.

## 1. Ağ adresini belirle
Ubuntu'da `hostname -I` komutuyla uygun LAN IPv4 adresini öğren. `infra/.env.example` dosyasını `infra/.env` olarak kopyala ve `HOST_IP` değerini değiştir. `RUNNER_TOKEN` başlangıçta `TOKEN_BURAYA` kalabilir. **HOST_IP değişirse Gitea ROOT_URL ve registry ayarlarını da güncelle.**

## 2. Gitea'yı başlat
```bash
cd infra
cp .env.example .env
nano .env
docker compose up -d gitea
docker compose ps
```
Tarayıcı: `http://HOST_IP:3001`. İlk Gitea kurulumunu tamamla, yönetici hesabı oluştur. 3001 host portu Gitea container'ının 3000 portuna gider. Var olan Gitea verin varsa bu yeni compose ile üzerine yazma; mevcut kuruluma runner eklemek daha doğru olabilir.

## 3. Runner token'ı al
Gitea'da site yönetimi (Site Administration) > Actions > Runners yolunu aç; yeni runner kayıt token'ını al (sürüme göre menü adı değişebilir). `infra/.env` içindeki `RUNNER_TOKEN` değerini doldur. Gizli token'ı Git'e ekleme.

## 4. Docker daemon HTTP registry izni
Bu örnekte image'lar `HOST_IP:3001/OWNER/python-ci-app` adresine gönderilecek. Docker daemon HTTPS beklediğinden test HTTP registry'si için host Docker Engine'e istisna ekle:
```bash
cd ..
HOST_IP=192.168.1.50 sudo -E bash scripts/setup-insecure-registry.sh
```
IP'yi kendi IP'nle değiştir. Script mevcut `/etc/docker/daemon.json` JSON ayarlarını koruyarak `insecure-registries` listesine adres ekler ve Docker'ı yeniden başlatır. **Önce dosyanın yedeğini al.** İş yeri politikasında buna izin yoksa scripti çalıştırma; TLS yapılandır.

## 5. Runner'ı başlat
```bash
cd infra
docker compose up -d runner
docker compose logs -f runner
```
Gitea > Actions > Runners ekranında runner'ın online/idle görünmesini bekle. Runner Docker socket'i kullandığı için host üzerinde yüksek yetkiye sahiptir. **Sadece güvenilir repository ve kullanıcılarla izole bir lab ortamında kullan.**

## 6. Repository oluştur
Gitea arayüzünde `python-ci-app` adlı boş repository oluştur. Varsayılan dal `main` olsun. Gitea URL'sini `http://HOST_IP:3001` olarak kullan.

## 7. Repository Actions değişkenleri ve secrets
Repo > Settings > Actions > Variables:
- `REGISTRY_HOST` = `HOST_IP:3001` (örn. `192.168.1.50:3001`)

Repo > Settings > Actions > Secrets:
- `REGISTRY_USERNAME` = Gitea kullanıcı adın
- `REGISTRY_TOKEN` = Gitea kişisel erişim token'ı (Packages yazma yetkisi olan, minimum izinli token)

Bu değerleri workflow dosyasına düz metin olarak yazma. Repo'da Actions özelliğinin açık olduğundan emin ol. Bazı sürümlerde workflow dosyalarının onaylanması gerekebilir.

## 8. Python projesini push et
```bash
cd ../python-app
git init
git branch -M main
git add .
git commit -m "Initial Python Docker CI pipeline"
git remote add origin http://HOST_IP:3001/OWNER/python-ci-app.git
git push -u origin main
```
`HOST_IP` ve `OWNER` değerlerini gerçek adres ve Gitea kullanıcı adıyla değiştir. HTTP Git kimlik doğrulamasında gerekirse erişim token'ı kullan.

## 9. Workflow nasıl çalışır?
`.gitea/workflows/build.yml` `main` dalına push geldiğinde tetiklenir. Runner, `node:20-bookworm` job container'ını başlatır, `actions/checkout@v4` ile kodu alır, Docker CLI kurar, host Docker daemon'ıyla image build eder, registry'ye giriş yapar ve iki tag'i push eder. Docker socket mount'u `runner-config.yaml` içindeki `container.options` ile verilir.

## 10. Sonuç doğrulama
Gitea repo > Actions sekmesinde workflow başarılı olmalı. Kullanıcı/organizasyon Packages sayfasında `python-ci-app` image'ı görünmeli. Host üzerinde:
```bash
docker login HOST_IP:3001
docker pull HOST_IP:3001/OWNER/python-ci-app:latest
docker run --rm -p 5000:5000 HOST_IP:3001/OWNER/python-ci-app:latest
```
Başka terminalde `curl http://localhost:5000/health` → `{"status":"healthy"}`.

## 11. Olası hatalar
- **Runner offline:** kayıt token'ı, URL, ağ, `docker compose logs runner`.
- **Runner job başlamıyor:** runner label (`ubuntu-latest`) ile workflow `runs-on` aynı mı?
- **Docker socket permission denied:** job container mount'u ve socket izinlerini incele; körlemesine `chmod 666` yapma.
- **HTTP response to HTTPS client:** Docker daemon insecure registry istisnasını kontrol et; daemon restart gerekebilir.
- **Connection refused:** `HOST_IP`, 3001 portu, firewall ve container'dan erişimi kontrol et.
- **401/403:** Packages yazma yetkisi ve token'ı kontrol et.
- **Checkout başarısız:** Actions etkinliği, repo erişimi ve Gitea URL'sini kontrol et.
- **DNS/hostname:** `localhost` container içinde host'u göstermez; host LAN IP veya uygun DNS adı kullan.

## Güvenlik ve uyumluluk notları
- Runner Docker socket mount'u pratik ama **host root seviyesinde risk** doğurur; iş yeri üretim ağında kullanılmamalıdır.
- Bu proje eğitim/lab içindir. Üretimde TLS registry, izole build node, sabit image sürümleri, token rotasyonu ve ayrı build daemon önerilir.
- Gitea/Runner sürümleri örnek sabit sürümlerdir. Image tag'leri yayınlanmış mı ve sürüm uyumluluğu mevcut mu kurulumdan önce doğrula; gerekirse desteklenen güncel sürümleri birlikte seç.
- Bu dosyalar burada gerçek Ubuntu ortamında çalıştırılıp test edilmedi. Özellikle Gitea sürümüne bağlı Actions secret/variable menüleri ve runner Docker ayarları doğrulanmalıdır.
