from flask import Flask, render_template_string
app = Flask(__name__)
@app.route("/login", methods=["GET"])
def login():
    return render_template_string("""
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Login Sayfası</title>
</head>
<body>
<h1>Giriş Sayfası</h1>
<form>
<input type="text" placeholder="Kullanıcı Adı">
<br><br>
<input type="password" placeholder="Şifre">
<br><br>
<button type="button">Giriş Yap</button>
</form>
</body>
</html>
""")
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
