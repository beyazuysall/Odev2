-- Replikasyon kullanıcısını oluştur
CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD 'replica_pass_2026';

-- Ham satış verilerinin tutulacağı tablo
CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(12,2) NOT NULL,
    unit_cost NUMERIC(12,2) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Python algoritmasının sonuçlarını yazacağı tablo
CREATE TABLE sales_analysis (
    order_id BIGINT PRIMARY KEY REFERENCES orders(id),
    total_sales NUMERIC(14,2) NOT NULL,
    total_cost NUMERIC(14,2) NOT NULL,
    profit NUMERIC(14,2) NOT NULL,
    profit_margin NUMERIC(6,2) NOT NULL,
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
