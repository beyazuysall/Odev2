#!/bin/bash
set -e

export PGPASSWORD="$REPLICATION_PASSWORD"

echo "Primary bekleniyor..."

until pg_isready -h postgres-primary -p 5432 -U postgres; do
    sleep 2
done

if [ ! -s "$PGDATA/PG_VERSION" ]; then

    echo "Primary'den başlangıç yedeği alınıyor..."

    find "$PGDATA" -mindepth 1 -maxdepth 1 -exec rm -rf {} +

    pg_basebackup \
        -h postgres-primary \
        -p 5432 \
        -U replicator \
        -D "$PGDATA" \
        -Fp \
        -Xs \
        -P \
        -R

fi

# PostgreSQL veri dizininin izinlerini düzelt
echo "Veri dizini izinleri ayarlanıyor..."

chmod 700 "$PGDATA"

echo "Replica başlatılıyor..."

exec postgres -D "$PGDATA"