import os
import psycopg2
from decimal import Decimal

password = os.environ["POSTGRES_PASSWORD"]

# READ: Replica bağlantısı
read_connection = psycopg2.connect(
    host="postgres-replica",
    port=5432,
    database="ecommerce",
    user="postgres",
    password=password
)

# WRITE: Primary bağlantısı
write_connection = psycopg2.connect(
    host="postgres-primary",
    port=5432,
    database="ecommerce",
    user="postgres",
    password=password
)

read_cursor = read_connection.cursor()
write_cursor = write_connection.cursor()

# Replica üzerinden verileri oku
read_cursor.execute("""
    SELECT id, quantity, unit_price, unit_cost
    FROM orders
    ORDER BY id
""")

orders = read_cursor.fetchall()

for order in orders:
    order_id, quantity, unit_price, unit_cost = order

    total_sales = quantity * unit_price
    total_cost = quantity * unit_cost
    profit = total_sales - total_cost

    profit_margin = (
        profit / total_sales * Decimal("100")
        if total_sales > 0
        else Decimal("0")
    )

    # Primary'ye analiz sonuçlarını yaz
    write_cursor.execute(
        """
        INSERT INTO sales_analysis
        (order_id, total_sales, total_cost, profit, profit_margin)
        VALUES (%s, %s, %s, %s, %s)
        ON CONFLICT (order_id)
        DO UPDATE SET
            total_sales = EXCLUDED.total_sales,
            total_cost = EXCLUDED.total_cost,
            profit = EXCLUDED.profit,
            profit_margin = EXCLUDED.profit_margin,
            analyzed_at = CURRENT_TIMESTAMP
        """,
        (
            order_id,
            total_sales,
            total_cost,
            profit,
            profit_margin
        )
    )

write_connection.commit()

print(f"{len(orders)} adet sipariş analiz edildi.")

read_cursor.close()
write_cursor.close()

read_connection.close()
write_connection.close()