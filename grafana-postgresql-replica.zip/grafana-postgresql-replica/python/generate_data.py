import os
import random
import psycopg2
from datetime import datetime, timedelta

connection = psycopg2.connect(
    host="postgres-primary",
    port=5432,
    database="ecommerce",
    user="postgres",
    password=os.environ["POSTGRES_PASSWORD"]
)

cursor = connection.cursor()

products = [
    ("Laptop", 30000, 24000),
    ("Mouse", 500, 300),
    ("Klavye", 1200, 800),
    ("Monitör", 8000, 6000),
    ("Kulaklık", 1500, 900),
    ("Webcam", 2500, 1800),
    ("SSD", 3500, 2700),
    ("RAM", 2000, 1400)
]

for _ in range(100):
    product_name, unit_price, unit_cost = random.choice(products)
    quantity = random.randint(1, 10)

    order_date = datetime.now() - timedelta(
        days=random.randint(0, 30)
    )

    cursor.execute(
        """
        INSERT INTO orders
        (product_name, quantity, unit_price, unit_cost, order_date)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (
            product_name,
            quantity,
            unit_price,
            unit_cost,
            order_date
        )
    )

connection.commit()

print("100 adet satış verisi Primary veritabanına yazıldı.")

cursor.close()
connection.close()